radproc\.core\.load\_years\_and\_resample
=========================================

.. currentmodule:: radproc.core

.. autofunction:: load_years_and_resample