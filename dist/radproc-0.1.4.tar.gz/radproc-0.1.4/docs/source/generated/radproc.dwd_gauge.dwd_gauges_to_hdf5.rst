radproc\.dwd\_gauge\.dwd\_gauges\_to\_hdf5
==========================================

.. currentmodule:: radproc.dwd_gauge

.. autofunction:: dwd_gauges_to_hdf5