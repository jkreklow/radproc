radproc\.arcgis\.idTable\_nineGrid
==================================

.. currentmodule:: radproc.arcgis

.. autofunction:: idTable_nineGrid