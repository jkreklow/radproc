radproc\.wradlib\_io\.read\_RADOLAN\_composite
==============================================

.. currentmodule:: radproc.wradlib_io

.. autofunction:: read_RADOLAN_composite