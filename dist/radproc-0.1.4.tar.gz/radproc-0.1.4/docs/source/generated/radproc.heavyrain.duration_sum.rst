radproc\.heavyrain\.duration\_sum
=================================

.. currentmodule:: radproc.heavyrain

.. autofunction:: duration_sum