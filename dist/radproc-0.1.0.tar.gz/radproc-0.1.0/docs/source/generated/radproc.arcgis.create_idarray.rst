radproc\.arcgis\.create\_idarray
================================

.. currentmodule:: radproc.arcgis

.. autofunction:: create_idarray