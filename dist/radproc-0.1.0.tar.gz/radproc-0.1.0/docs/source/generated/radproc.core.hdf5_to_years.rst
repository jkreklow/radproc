radproc\.core\.hdf5\_to\_years
==============================

.. currentmodule:: radproc.core

.. autofunction:: hdf5_to_years