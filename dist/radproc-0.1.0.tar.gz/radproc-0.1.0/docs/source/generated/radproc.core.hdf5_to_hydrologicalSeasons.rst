radproc\.core\.hdf5\_to\_hydrologicalSeasons
============================================

.. currentmodule:: radproc.core

.. autofunction:: hdf5_to_hydrologicalSeasons