radproc\.heavyrain\.count\_heavy\_rainfall\_intervals
=====================================================

.. currentmodule:: radproc.heavyrain

.. autofunction:: count_heavy_rainfall_intervals