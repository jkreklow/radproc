radproc\.arcgis\.raster\_to\_array
==================================

.. currentmodule:: radproc.arcgis

.. autofunction:: raster_to_array