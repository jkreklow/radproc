radproc\.raw\.create\_idraster\_and\_process\_radolan\_data
===========================================================

.. currentmodule:: radproc.raw

.. autofunction:: create_idraster_and_process_radolan_data