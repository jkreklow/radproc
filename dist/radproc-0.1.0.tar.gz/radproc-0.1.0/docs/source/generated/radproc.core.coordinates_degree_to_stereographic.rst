radproc\.core\.coordinates\_degree\_to\_stereographic
=====================================================

.. currentmodule:: radproc.core

.. autofunction:: coordinates_degree_to_stereographic