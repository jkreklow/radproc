radproc\.heavyrain\.find\_heavy\_rainfalls
==========================================

.. currentmodule:: radproc.heavyrain

.. autofunction:: find_heavy_rainfalls