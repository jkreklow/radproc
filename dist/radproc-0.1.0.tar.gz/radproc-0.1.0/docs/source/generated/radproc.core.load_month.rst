radproc\.core\.load\_month
==========================

.. currentmodule:: radproc.core

.. autofunction:: load_month