radproc\.raw\.process\_radolan\_data
====================================

.. currentmodule:: radproc.raw

.. autofunction:: process_radolan_data