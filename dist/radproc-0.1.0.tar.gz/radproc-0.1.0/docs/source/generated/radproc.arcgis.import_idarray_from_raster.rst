radproc\.arcgis\.import\_idarray\_from\_raster
==============================================

.. currentmodule:: radproc.arcgis

.. autofunction:: import_idarray_from_raster