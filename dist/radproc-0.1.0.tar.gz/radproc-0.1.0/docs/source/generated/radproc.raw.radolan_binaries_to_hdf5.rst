radproc\.raw\.radolan\_binaries\_to\_hdf5
=========================================

.. currentmodule:: radproc.raw

.. autofunction:: radolan_binaries_to_hdf5