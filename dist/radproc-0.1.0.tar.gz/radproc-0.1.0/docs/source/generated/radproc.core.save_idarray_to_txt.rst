radproc\.core\.save\_idarray\_to\_txt
=====================================

.. currentmodule:: radproc.core

.. autofunction:: save_idarray_to_txt