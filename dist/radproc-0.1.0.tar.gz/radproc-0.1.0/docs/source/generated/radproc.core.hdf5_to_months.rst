radproc\.core\.hdf5\_to\_months
===============================

.. currentmodule:: radproc.core

.. autofunction:: hdf5_to_months