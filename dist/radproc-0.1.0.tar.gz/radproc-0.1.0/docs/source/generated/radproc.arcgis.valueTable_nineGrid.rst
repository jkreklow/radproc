radproc\.arcgis\.valueTable\_nineGrid
=====================================

.. currentmodule:: radproc.arcgis

.. autofunction:: valueTable_nineGrid