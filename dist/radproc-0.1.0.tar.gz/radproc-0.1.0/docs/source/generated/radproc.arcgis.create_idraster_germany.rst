radproc\.arcgis\.create\_idraster\_germany
==========================================

.. currentmodule:: radproc.arcgis

.. autofunction:: create_idraster_germany