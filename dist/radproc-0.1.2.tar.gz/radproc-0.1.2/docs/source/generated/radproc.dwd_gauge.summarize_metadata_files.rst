radproc\.dwd\_gauge\.summarize\_metadata\_files
===============================================

.. currentmodule:: radproc.dwd_gauge

.. autofunction:: summarize_metadata_files