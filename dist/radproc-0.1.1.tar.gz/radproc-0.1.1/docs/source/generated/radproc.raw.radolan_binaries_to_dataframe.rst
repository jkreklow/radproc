radproc\.raw\.radolan\_binaries\_to\_dataframe
==============================================

.. currentmodule:: radproc.raw

.. autofunction:: radolan_binaries_to_dataframe