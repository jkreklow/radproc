radproc\.dwd\_gauge\.stationfile\_to\_df
========================================

.. currentmodule:: radproc.dwd_gauge

.. autofunction:: stationfile_to_df