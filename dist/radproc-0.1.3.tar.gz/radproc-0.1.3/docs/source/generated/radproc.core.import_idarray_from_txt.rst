radproc\.core\.import\_idarray\_from\_txt
=========================================

.. currentmodule:: radproc.core

.. autofunction:: import_idarray_from_txt