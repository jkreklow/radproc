radproc\.arcgis\.clip\_idraster
===============================

.. currentmodule:: radproc.arcgis

.. autofunction:: clip_idraster