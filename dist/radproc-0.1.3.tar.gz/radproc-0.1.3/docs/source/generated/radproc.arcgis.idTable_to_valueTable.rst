radproc\.arcgis\.idTable\_to\_valueTable
========================================

.. currentmodule:: radproc.arcgis

.. autofunction:: idTable_to_valueTable